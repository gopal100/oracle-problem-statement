package oracle;

import java.util.Scanner;

public class EncryptString {

	public static String encrytText(String str) throws EncryptionException {

		StringBuilder encryptedText = new StringBuilder();

		if(str != null && str.length() > 0) {

			//Get the length of the text after removing spaces
			String textWIthoutSpace = str.replace(" ", "");
			int totalLenExSpace = textWIthoutSpace.length();
			if(totalLenExSpace == 0) {
				throw new EncryptionException("Text contains empty spaces only");
			}

			//Get the square root of the value
			double sqrt = Math.sqrt(totalLenExSpace);

			//Get square root of largest perfect square number less than or equals to totalLenExSpace
			int preSqrt = (int) Math.floor(sqrt);

			//Get square root of smallest perfect square number greater than or equals to totalLenExSpace
			int postSqrt = (int) Math.ceil(sqrt);

			/*
			 *  Checking if R*C >= L or not. Hence product of preSqrt and postSqrt must be greater than totalLenExSpace.
			 *  Also the condition preSqrt <= R<=C<=postSqrt. Hence if at some point preSqrt becomes greater than postSqrt and 
			 *  still preSqrt*postSqrt >= totalLenExSpace condition doesn't get satisfied then we will raise an error since the 
			 *  business rule is not meeting.
			 */
			while(preSqrt*postSqrt < totalLenExSpace) {
				preSqrt++;
				if((preSqrt > postSqrt) && (preSqrt*postSqrt < totalLenExSpace)) {
					throw new EncryptionException("Text can not be encrypted since the business rule is not satisfying");
				}
			}

			/*
			 * Populate the two dimensional array from the textWIthoutSpace string based on values of preSqrt and postSqrt
			 */
			char[][] chrs = new char[preSqrt][postSqrt];
			int rowCnt =0, columnCnt = 0;
			for (char cs : textWIthoutSpace.toCharArray()) {
				chrs[rowCnt][columnCnt++] = cs;
				if(columnCnt == postSqrt) {
					rowCnt++;
					columnCnt = 0;
				}
			}

			/*
			 * Get the encrypted string by traversing the two-D array and then appends to encryptedText
			 * only if the character in the array is not empty
			 */
			for(int col =0; col < chrs[0].length; col++) {
				for(int row = 0; row < chrs.length; row++) {
					if(chrs[row][col] != '\u0000') {
						encryptedText.append(chrs[row][col]);
					}
				}
				// for last column do not append space
				if(col < chrs[0].length-1) {
					encryptedText.append(" ");
				}
			}
		}

		// Returns the Encrypted String
		return encryptedText.toString();
	}

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		System.out.println("Please enter the text you want to encrypt :: ");

		String enteredText = scanner.nextLine();
		System.out.println("You have entered >> "+enteredText);
		String encryptedText = null;
		try {
			encryptedText = encrytText(enteredText);
			System.out.println("Encrypted text >> "+encryptedText);
		} catch (EncryptionException e) {
			System.err.println(e.getMessage());
		}

		scanner.close();
	}

}
