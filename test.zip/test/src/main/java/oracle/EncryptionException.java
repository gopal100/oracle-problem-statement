package oracle;

public class EncryptionException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3404395099645326704L;
	
	public EncryptionException(String message) {
		super(message);
	}

}
