package test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import oracle.EncryptString;
import oracle.EncryptionException;

public class TestEncryptString {
	
	
	@Test
	public void encrytText() throws EncryptionException {
		assertEquals("tcuno hkmtf ecph baee ltdr ajoo", EncryptString.encrytText("the black cat jumped on the roof"));
		assertEquals("clu hlt io", EncryptString.encrytText("chill out"));
	}

}
